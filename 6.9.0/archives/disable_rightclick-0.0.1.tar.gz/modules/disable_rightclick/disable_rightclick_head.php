<script type="text/javascript">
window.oncontextmenu = function() {
    return false; /* prevent context menu from popping up */
};
</script>
