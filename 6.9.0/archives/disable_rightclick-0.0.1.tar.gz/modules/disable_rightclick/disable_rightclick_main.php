<?php
function disable_rightclick_render(){
     return "";
     }
?>
