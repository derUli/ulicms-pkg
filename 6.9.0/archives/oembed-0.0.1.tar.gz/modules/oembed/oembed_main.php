<?php
function oembed_render(){
     return "";
     }
?>