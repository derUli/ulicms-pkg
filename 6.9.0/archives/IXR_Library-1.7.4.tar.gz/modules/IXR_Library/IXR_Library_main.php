<?php
function IXR_Library_render(){
     return "nix";
    }
?>