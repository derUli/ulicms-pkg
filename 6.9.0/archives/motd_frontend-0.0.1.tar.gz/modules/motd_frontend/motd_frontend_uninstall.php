<?php
deleteconfig("cache_disabled");
?>