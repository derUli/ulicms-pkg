<?php
function trackback_cls_render(){
     return '<a href="' . getModulePath("trackback_cls") . 'documentation/index.html">trackback_cls Dokumentation aufrufen</a>';
    }
?>
