<?php
function lastRSS_render(){
     return "Dieses Modul hat keine eigene Ausgabe da es eine nur eine PHP-Klasse enthält."
    }
?>