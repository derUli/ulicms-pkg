<?php
global $acl_array;
$acl_array["phpinfo"] = null;
