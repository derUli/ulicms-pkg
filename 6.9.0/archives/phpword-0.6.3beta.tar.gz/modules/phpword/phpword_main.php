<?php
function phpword_render(){
     return "";
     }
?>