<?php
global $acl_array;
$acl_array["xml_sitemap"] = null;
