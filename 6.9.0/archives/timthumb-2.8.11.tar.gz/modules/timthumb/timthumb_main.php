<?php

function timthumb_render(){
     return "";
     }
?>