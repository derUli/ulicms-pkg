<?php
global $acl_array;
$acl_array["limit_login_attempts"] = null;
