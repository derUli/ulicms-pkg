<p style="text-align:center;"><?php random_banner()?></p>
</div>			
</div>	
		

			</div>

			<!-- primary content end -->
	
		</div>
		
		<div id="secondarycontent">

			<!-- secondary content start -->
		
			<h3>Über Mich</h3>
			<div class="content">
				<img src="<?php echo getTemplateDirPath("terrafirma");
?>images/pic2.jpg" class="picB" alt="" />
				<p><strong>Nullam turpis</strong> vestibulum et sed dolore. Nulla facilisi. Sed tortor. lobortis commodo. <a href="#">More ...</a></p>
			</div>
			
			<h3>Topics</h3>
			<div class="content">
				<ul class="linklist">
				<?php menu("right");
?>
			</div>

			<!-- secondary content end -->

		</div>
	
		<div id="footer">
		
			&copy; <?php homepage_owner();
?> All rights reserved. Design by <a href="http://www.nodethirtythree.com/">NodeThirtyThree</a>. | <a href="http://www.ulicms.de" target="_blank">Powered by UliCMS</a> 
		
		</div>

	</div>

</div>

</body>
</html>