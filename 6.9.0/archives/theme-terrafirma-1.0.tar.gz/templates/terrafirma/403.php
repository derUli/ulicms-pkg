<h2>Zugriff verweigert</h2>
<p>Sie verfügen nicht über die Rechte, um auf diese Seite zuzugreifen.<br/>
Sind sie eingeloggt?</p>