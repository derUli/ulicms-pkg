<?php
global $acl_array;
$acl_array["kontaktformular_settings"] = null;
