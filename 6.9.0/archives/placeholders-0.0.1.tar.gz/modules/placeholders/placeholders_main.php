<?php
function placeholders_render(){
     return "";
    }
