<?php 
function dummy_render(){
  return "Ich bin nur ein Dummy Modul!";
}
?>