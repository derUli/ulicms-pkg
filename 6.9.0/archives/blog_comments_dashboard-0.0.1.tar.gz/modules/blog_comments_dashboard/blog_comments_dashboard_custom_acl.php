<?php
global $acl_array;
$acl_array["blog_comments_dashboard"] = null;
