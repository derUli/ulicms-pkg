var CountdownImageFolder = "<?php echo getModulePath("countdown")."images/"?>";
var CountdownImageBasename = "flipper";
var CountdownImageExt = "png";
var CountdownImagePhysicalWidth = 41;
var CountdownImagePhysicalHeight = 60;
