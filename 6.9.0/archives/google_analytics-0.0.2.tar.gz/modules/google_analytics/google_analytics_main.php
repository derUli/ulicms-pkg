<?php
function google_analytics_render(){
     return "";
     }
?>