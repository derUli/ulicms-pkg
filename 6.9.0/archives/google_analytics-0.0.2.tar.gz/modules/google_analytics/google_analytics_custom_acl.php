<?php
global $acl_array;
$acl_array["google_analytics"] = null;
