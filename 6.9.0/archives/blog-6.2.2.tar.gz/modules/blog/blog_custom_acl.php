<?php
global $acl_array;

$acl_array["blog_settings"] = null;
$acl_array["blog"] = null;
