<script type="text/javascript" src="<?php echo getModulePath("schnee")?>schnee.js"></script>
