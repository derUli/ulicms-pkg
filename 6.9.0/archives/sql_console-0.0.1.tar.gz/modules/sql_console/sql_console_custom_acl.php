<?php
global $acl_array;
$acl_array["sql_console"] = null;
