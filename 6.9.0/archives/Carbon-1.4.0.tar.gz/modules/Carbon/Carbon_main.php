<?php
function carbon_render(){
     return "<a href=\"https://github.com/briannesbitt/Carbon\">Carbon Homepage</a>";
    }
?>