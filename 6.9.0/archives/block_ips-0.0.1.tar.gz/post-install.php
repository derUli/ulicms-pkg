<?php
if(!getconfig("blocked_ips"))
     setconfig("blocked_ips", "");
