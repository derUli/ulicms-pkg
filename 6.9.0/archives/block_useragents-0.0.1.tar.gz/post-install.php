<?php
	if(!getconfig("blocked_useragents"))
     setconfig("blocked_useragents", "");
