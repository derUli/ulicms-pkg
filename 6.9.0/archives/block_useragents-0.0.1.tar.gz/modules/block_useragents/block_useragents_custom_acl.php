<?php
global $acl_array;
$acl_array["block_useragents"] = null;
