<?php
function remote_api_render(){
     return "Nix";
    }

?>