<?php
global $acl_array;
$acl_array["remote_api_settings"] = null;
