<?php
deleteconfig("hide_meta_generator");
?>
