<?php
function hide_meta_generator_render(){
     return "";
     }
?>
