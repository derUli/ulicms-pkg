<?php
global $acl_array;
$acl_array["blog2twitter_settings"] = null;
