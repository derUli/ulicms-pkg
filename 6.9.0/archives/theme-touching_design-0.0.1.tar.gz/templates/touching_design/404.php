<h2>Seite nicht gefunden</h2>
<p>Diese Seite existiert nicht mehr<br/>
Eventuell sind Sie einem toten Link gefolgt?</p>