<p><?php random_banner()?></p>
		</div><!-- end content -->
		</div><!-- end inner -->
	</div><!-- end outer -->
 	<div id="footer"><h1>&copy; <?php year()?> by <?php homepage_owner()?> | Powered by UliCMS <?php echo cms_version();
?></h1></div>
 	
</div><!-- end container -->
</body></html>
