<?php
global $acl_array;

$acl_array["fullcalendar_edit"] = null;
