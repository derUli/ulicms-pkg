<?php
global $acl_array;
$acl_array["gallery_setings"] = null;
