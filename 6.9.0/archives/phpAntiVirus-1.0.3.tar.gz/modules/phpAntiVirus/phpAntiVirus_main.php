<?php
function phpAntiVirus_render(){
     return "";
     }
?>