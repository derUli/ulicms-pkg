<?php
function compress_html_render(){
    
     }
?>
