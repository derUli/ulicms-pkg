<?php
global $acl_array;
$acl_array["link_checker"] = null;
