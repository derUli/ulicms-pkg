<?php
db_query("CREATE TABLE IF NOT EXISTS `" . tbname("search_subjects") . "` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) NOT NULL,
  `amount` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");

if(getconfig("search_subjects_limit") === false)
     setconfig("search_subjects_limit", "10");

?>