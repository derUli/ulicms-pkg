<?php
db_query("DROP TABLE `" . tbname("search_subjects") . "`");
?>