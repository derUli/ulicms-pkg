<?php
global $acl_array;
$acl_array["search_subjects"] = null;
