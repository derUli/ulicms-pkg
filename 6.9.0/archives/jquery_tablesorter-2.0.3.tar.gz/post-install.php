<p>jquery_tablesorter_theme setzen ...
<?php setconfig("jquery_tablesorter_theme", "blue");
?>
 [Erledigt]
 </p>
