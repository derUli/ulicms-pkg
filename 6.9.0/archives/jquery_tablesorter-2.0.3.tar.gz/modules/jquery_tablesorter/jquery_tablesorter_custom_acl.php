<?php
global $acl_array;
$acl_array["jquery_tablesorter_settings"] = null;
