<?php
function jquery_tablesorter_render(){
     return "";
    }
?>
