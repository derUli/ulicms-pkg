<?php
function stringparser_bbcode_render(){
     return "Keine Frontend Ausgabe!";
    }
?>