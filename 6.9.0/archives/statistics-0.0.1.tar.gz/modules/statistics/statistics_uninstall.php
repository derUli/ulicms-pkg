<?php
db_query("DROP TABLE `" . tbname("statistics") . "`");
?>