<?php
function typographic_quotes_render(){
     return "";
     }
?>